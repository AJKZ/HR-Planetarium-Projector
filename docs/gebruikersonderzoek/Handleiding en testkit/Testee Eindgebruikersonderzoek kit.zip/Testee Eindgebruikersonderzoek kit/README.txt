Deze map bevat de volgende items om deel te nemen aan het eindgebruikersonderzoek:
- GUI Executable
- Stars datamap
- Enquête in .docx format
- Icon in .png format

Bij het extracten, laat de executable, datamap en icon in dezelfde map staan, run van daaruit de executable. 
De enquête graag invullen en opslaan onder dezelfde naam. 
De map opnieuw zippen en doorsturen via Microsoft Teams naar Britt Reijnders - 0961943